# Build status

Source-level checks completed in the ChatGPT execution environment:

- Core Kotlin model/formatting files compile with the available Kotlin compiler.
- All Android XML files are well-formed.
- Manifest contains fine-location, foreground-service and foreground-location declarations.
- Location service is declared with `foregroundServiceType="location"`.

A full APK build was not possible in this execution environment because Android SDK and Gradle are not installed and outbound package downloads are unavailable from the container.

Open the project in a current Android Studio, install Android SDK 36 if prompted, then run the `app` debug configuration or `assembleDebug`.
