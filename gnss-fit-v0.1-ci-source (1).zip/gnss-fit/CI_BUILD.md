# Automatic APK build

The project includes `.github/workflows/build-apk.yml`.

It builds with:
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- JDK 17
- compileSdk 36
- Android Build Tools 36.0.0

After pushing the project to GitHub, the workflow runs automatically on `main` or `master`, and can also be started manually with **Actions → Build Android APK → Run workflow**.

The resulting debug APK is published as the workflow artifact `gnss-fit-debug-apk`.
