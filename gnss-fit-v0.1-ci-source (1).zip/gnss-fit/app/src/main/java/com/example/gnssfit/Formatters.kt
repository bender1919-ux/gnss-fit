package com.example.gnssfit

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

object Formatters {
    fun duration(ms: Long): String {
        val totalSeconds = ms / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return if (hours > 0) "%d:%02d:%02d".format(hours, minutes, seconds)
        else "%02d:%02d".format(minutes, seconds)
    }

    fun distance(meters: Double): String = if (meters < 1000) {
        "${meters.roundToInt()} м"
    } else {
        String.format(Locale.US, "%.2f км", meters / 1000.0)
    }

    fun speedKmh(mps: Double): String = String.format(Locale.US, "%.1f км/ч", mps * 3.6)

    fun pace(mps: Double): String {
        if (mps < 0.3) return "—"
        val secPerKm = (1000.0 / mps).roundToInt()
        val min = secPerKm / 60
        val sec = secPerKm % 60
        return "%d:%02d /км".format(min, sec)
    }

    fun date(timeMs: Long): String = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date(timeMs))
}
