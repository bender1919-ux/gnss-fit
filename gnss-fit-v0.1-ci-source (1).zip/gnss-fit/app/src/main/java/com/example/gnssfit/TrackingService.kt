package com.example.gnssfit

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.location.GnssStatus
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper

class TrackingService : Service() {
    private lateinit var locationManager: LocationManager
    private val handler = Handler(Looper.getMainLooper())
    private var locationRegistered = false
    private var gnssRegistered = false

    private val tick = object : Runnable {
        override fun run() {
            TrackingRepository.tick()
            updateNotification()
            if (TrackingRepository.snapshot().status != WorkoutStatus.IDLE) {
                handler.postDelayed(this, 1000L)
            }
        }
    }

    private val locationListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            TrackingRepository.acceptLocation(location)
        }

        override fun onProviderDisabled(provider: String) {
            TrackingRepository.tick()
        }
    }

    private val gnssCallback = object : GnssStatus.Callback() {
        override fun onSatelliteStatusChanged(status: GnssStatus) {
            var gps = 0
            var glonass = 0
            var galileo = 0
            var beidou = 0
            var other = 0
            var used = 0
            for (i in 0 until status.satelliteCount) {
                if (status.usedInFix(i)) used++
                when (status.getConstellationType(i)) {
                    GnssStatus.CONSTELLATION_GPS -> gps++
                    GnssStatus.CONSTELLATION_GLONASS -> glonass++
                    GnssStatus.CONSTELLATION_GALILEO -> galileo++
                    GnssStatus.CONSTELLATION_BEIDOU -> beidou++
                    else -> other++
                }
            }
            TrackingRepository.updateGnss(
                GnssInfo(
                    visible = status.satelliteCount,
                    usedInFix = used,
                    gps = gps,
                    glonass = glonass,
                    galileo = galileo,
                    beidou = beidou,
                    other = other
                )
            )
        }
    }

    override fun onCreate() {
        super.onCreate()
        locationManager = getSystemService(LocationManager::class.java)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    stopSelf()
                    return START_NOT_STICKY
                }
                val type = ActivityType.fromName(intent.getStringExtra(EXTRA_ACTIVITY_TYPE))
                TrackingRepository.start(type)
                startForeground(NOTIFICATION_ID, buildNotification())
                registerGnss()
                registerLocation()
                handler.removeCallbacks(tick)
                handler.post(tick)
            }
            ACTION_PAUSE -> {
                TrackingRepository.pause()
                unregisterLocation()
                updateNotification()
            }
            ACTION_RESUME -> {
                TrackingRepository.resume()
                registerLocation()
                updateNotification()
            }
            ACTION_STOP -> finishWorkout()
        }
        return START_NOT_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        unregisterLocation()
        unregisterGnss()
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun registerLocation() {
        if (locationRegistered) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        if (!locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)) return
        locationManager.requestLocationUpdates(
            LocationManager.GPS_PROVIDER,
            1000L,
            0f,
            locationListener,
            Looper.getMainLooper()
        )
        locationRegistered = true
    }

    private fun unregisterLocation() {
        if (!locationRegistered) return
        runCatching { locationManager.removeUpdates(locationListener) }
        locationRegistered = false
    }

    private fun registerGnss() {
        if (gnssRegistered) return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        gnssRegistered = runCatching {
            locationManager.registerGnssStatusCallback(gnssCallback, handler)
        }.getOrDefault(false)
    }

    private fun unregisterGnss() {
        if (!gnssRegistered) return
        runCatching { locationManager.unregisterGnssStatusCallback(gnssCallback) }
        gnssRegistered = false
    }

    private fun finishWorkout() {
        unregisterLocation()
        unregisterGnss()
        handler.removeCallbacksAndMessages(null)
        val snapshot = TrackingRepository.finishSnapshot()
        if (snapshot.startWallTimeMs > 0L && (snapshot.elapsedMs >= 1000L || snapshot.route.isNotEmpty())) {
            WorkoutStore.save(this, snapshot)
        }
        TrackingRepository.reset()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun createNotificationChannel() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Запись тренировки", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Показывает активную GNSS-тренировку"
                setShowBadge(false)
            }
        )
    }

    private fun buildNotification(): Notification {
        val state = TrackingRepository.snapshot()
        val contentIntent = PendingIntent.getActivity(
            this,
            1,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = Notification.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_app)
            .setContentTitle("${state.activityType.title} • ${Formatters.duration(state.elapsedMs)}")
            .setContentText("${Formatters.distance(state.distanceM)} • ${Formatters.speedKmh(state.averageSpeedMps)}")
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(contentIntent)
            .setCategory(Notification.CATEGORY_SERVICE)

        val toggleAction = if (state.status == WorkoutStatus.PAUSED) ACTION_RESUME else ACTION_PAUSE
        val toggleTitle = if (state.status == WorkoutStatus.PAUSED) "Продолжить" else "Пауза"
        val toggleIcon = if (state.status == WorkoutStatus.PAUSED) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause
        builder.addAction(
            Notification.Action.Builder(toggleIcon, toggleTitle, servicePendingIntent(toggleAction, 10)).build()
        )
        builder.addAction(
            Notification.Action.Builder(android.R.drawable.ic_menu_close_clear_cancel, "Завершить", servicePendingIntent(ACTION_STOP, 11)).build()
        )
        return builder.build()
    }

    private fun updateNotification() {
        if (TrackingRepository.snapshot().status == WorkoutStatus.IDLE) return
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
    }

    private fun servicePendingIntent(action: String, requestCode: Int): PendingIntent = PendingIntent.getService(
        this,
        requestCode,
        Intent(this, TrackingService::class.java).setAction(action),
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    companion object {
        const val ACTION_START = "com.example.gnssfit.START"
        const val ACTION_PAUSE = "com.example.gnssfit.PAUSE"
        const val ACTION_RESUME = "com.example.gnssfit.RESUME"
        const val ACTION_STOP = "com.example.gnssfit.STOP"
        const val EXTRA_ACTIVITY_TYPE = "activityType"
        private const val CHANNEL_ID = "tracking"
        private const val NOTIFICATION_ID = 1001
    }
}
