package com.example.gnssfit

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos

class RouteView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    var points: List<TrackPoint> = emptyList()
        set(value) {
            field = value
            invalidate()
        }

    private val gridPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(36, 52, 75)
        strokeWidth = 1f
    }
    private val routePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(94, 225, 162)
        style = Paint.Style.STROKE
        strokeWidth = 6f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val startPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val endPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.rgb(94, 225, 162) }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(170, 183, 200)
        textSize = 34f
        textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(Color.rgb(15, 24, 40))
        val step = width / 6f
        for (i in 1 until 6) {
            canvas.drawLine(i * step, 0f, i * step, height.toFloat(), gridPaint)
            canvas.drawLine(0f, i * height / 6f, width.toFloat(), i * height / 6f, gridPaint)
        }

        if (points.isEmpty()) {
            canvas.drawText("Ожидание GNSS-фиксации…", width / 2f, height / 2f, textPaint)
            return
        }

        val pad = 28f
        val minLat = points.minOf { it.lat }
        val maxLat = points.maxOf { it.lat }
        val minLon = points.minOf { it.lon }
        val maxLon = points.maxOf { it.lon }
        val midLatRad = ((minLat + maxLat) / 2.0) * Math.PI / 180.0
        val lonScale = cos(midLatRad).coerceAtLeast(0.2)
        val latSpan = (maxLat - minLat).coerceAtLeast(0.00002)
        val lonSpan = ((maxLon - minLon) * lonScale).coerceAtLeast(0.00002)
        val drawableW = (width - 2 * pad).coerceAtLeast(1f)
        val drawableH = (height - 2 * pad).coerceAtLeast(1f)
        val scale = minOf(drawableW / lonSpan.toFloat(), drawableH / latSpan.toFloat())
        val contentW = lonSpan.toFloat() * scale
        val contentH = latSpan.toFloat() * scale
        val xOffset = (width - contentW) / 2f
        val yOffset = (height - contentH) / 2f

        fun mapX(lon: Double): Float = xOffset + (((lon - minLon) * lonScale).toFloat() * scale)
        fun mapY(lat: Double): Float = yOffset + contentH - ((lat - minLat).toFloat() * scale)

        if (points.size == 1) {
            canvas.drawCircle(width / 2f, height / 2f, 9f, endPaint)
            return
        }

        val path = Path()
        points.forEachIndexed { index, p ->
            val x = mapX(p.lon)
            val y = mapY(p.lat)
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        canvas.drawPath(path, routePaint)
        val first = points.first()
        val last = points.last()
        canvas.drawCircle(mapX(first.lon), mapY(first.lat), 9f, startPaint)
        canvas.drawCircle(mapX(last.lon), mapY(last.lat), 11f, endPaint)
    }
}
