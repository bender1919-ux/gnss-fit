package com.example.gnssfit

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class WorkoutDetailActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val workout = intent.getStringExtra("id")?.let { WorkoutStore.loadWorkout(this, it) }
        if (workout == null) {
            finish()
            return
        }
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11, 18, 32)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = workout.summary.activityType.title
            setTextColor(Color.WHITE)
            textSize = 28f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = Formatters.date(workout.summary.startWallTimeMs)
            setTextColor(Color.rgb(170, 183, 200))
            textSize = 14f
            setPadding(0, dp(2), 0, dp(16))
        })

        root.addView(RouteView(this).apply { points = workout.route }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(300)).apply {
            bottomMargin = dp(18)
        })
        addLine(root, "Дистанция", Formatters.distance(workout.summary.distanceM))
        addLine(root, "Время", Formatters.duration(workout.summary.elapsedMs))
        addLine(root, "Средняя скорость", Formatters.speedKmh(workout.summary.averageSpeedMps))
        addLine(root, "Средний темп", Formatters.pace(workout.summary.averageSpeedMps))
        addLine(root, "Точек маршрута", workout.route.size.toString())
        setContentView(scroll)
    }

    private fun addLine(root: LinearLayout, label: String, value: String) {
        root.addView(TextView(this).apply {
            text = "$label: $value"
            setTextColor(Color.WHITE)
            textSize = 17f
            setPadding(0, dp(5), 0, dp(5))
        })
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
