package com.example.gnssfit

import android.location.Location
import android.os.SystemClock
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.max

object TrackingRepository {
    private val listeners = CopyOnWriteArraySet<(TrackingSnapshot) -> Unit>()
    private val route = mutableListOf<TrackPoint>()

    private var status = WorkoutStatus.IDLE
    private var activityType = ActivityType.RUN
    private var startWallTimeMs = 0L
    private var activeAccumulatedMs = 0L
    private var activeSegmentStartedElapsed = 0L
    private var distanceM = 0.0
    private var currentSpeedMps = 0f
    private var accuracyM: Float? = null
    private var gnss = GnssInfo()
    private var lastAcceptedLocation: Location? = null

    @Synchronized
    fun start(type: ActivityType) {
        route.clear()
        status = WorkoutStatus.ACTIVE
        activityType = type
        startWallTimeMs = System.currentTimeMillis()
        activeAccumulatedMs = 0L
        activeSegmentStartedElapsed = SystemClock.elapsedRealtime()
        distanceM = 0.0
        currentSpeedMps = 0f
        accuracyM = null
        gnss = GnssInfo()
        lastAcceptedLocation = null
        emitLocked()
    }

    @Synchronized
    fun pause() {
        if (status != WorkoutStatus.ACTIVE) return
        activeAccumulatedMs += SystemClock.elapsedRealtime() - activeSegmentStartedElapsed
        status = WorkoutStatus.PAUSED
        currentSpeedMps = 0f
        emitLocked()
    }

    @Synchronized
    fun resume() {
        if (status != WorkoutStatus.PAUSED) return
        status = WorkoutStatus.ACTIVE
        activeSegmentStartedElapsed = SystemClock.elapsedRealtime()
        lastAcceptedLocation = null
        emitLocked()
    }

    @Synchronized
    fun tick() {
        if (status != WorkoutStatus.IDLE) emitLocked()
    }

    @Synchronized
    fun updateGnss(info: GnssInfo) {
        gnss = info
        emitLocked()
    }

    @Synchronized
    fun acceptLocation(location: Location) {
        if (status != WorkoutStatus.ACTIVE) return
        if (location.accuracy <= 0f || location.accuracy > 35f) {
            accuracyM = location.accuracy.takeIf { it > 0f }
            emitLocked()
            return
        }

        accuracyM = location.accuracy
        val previous = lastAcceptedLocation
        if (previous != null) {
            val dtSeconds = max(0.5, (location.time - previous.time) / 1000.0)
            val stepM = previous.distanceTo(location).toDouble()
            val impliedSpeed = stepM / dtSeconds
            val plausible = impliedSpeed <= activityType.maxPlausibleSpeedMps || stepM <= max(8.0, location.accuracy.toDouble())
            if (!plausible) {
                emitLocked()
                return
            }
            if (stepM >= 1.5) distanceM += stepM
        }

        val speed = when {
            location.hasSpeed() && location.speed >= 0f -> location.speed
            previous != null -> {
                val dt = max(0.5, (location.time - previous.time) / 1000.0)
                (previous.distanceTo(location) / dt).toFloat()
            }
            else -> 0f
        }
        currentSpeedMps = if (speed < 0.4f) 0f else speed.coerceAtMost(activityType.maxPlausibleSpeedMps)

        route += TrackPoint(
            lat = location.latitude,
            lon = location.longitude,
            altitude = if (location.hasAltitude()) location.altitude else 0.0,
            timeMs = location.time,
            accuracyM = location.accuracy,
            speedMps = currentSpeedMps
        )
        lastAcceptedLocation = Location(location)
        emitLocked()
    }

    @Synchronized
    fun finishSnapshot(): TrackingSnapshot {
        if (status == WorkoutStatus.ACTIVE) {
            activeAccumulatedMs += SystemClock.elapsedRealtime() - activeSegmentStartedElapsed
        }
        status = WorkoutStatus.PAUSED
        currentSpeedMps = 0f
        return snapshotLocked()
    }

    @Synchronized
    fun reset() {
        status = WorkoutStatus.IDLE
        route.clear()
        startWallTimeMs = 0L
        activeAccumulatedMs = 0L
        activeSegmentStartedElapsed = 0L
        distanceM = 0.0
        currentSpeedMps = 0f
        accuracyM = null
        gnss = GnssInfo()
        lastAcceptedLocation = null
        emitLocked()
    }

    @Synchronized
    fun snapshot(): TrackingSnapshot = snapshotLocked()

    fun addListener(listener: (TrackingSnapshot) -> Unit) {
        listeners += listener
        listener(snapshot())
    }

    fun removeListener(listener: (TrackingSnapshot) -> Unit) {
        listeners -= listener
    }

    private fun elapsedLocked(): Long = when (status) {
        WorkoutStatus.ACTIVE -> activeAccumulatedMs + (SystemClock.elapsedRealtime() - activeSegmentStartedElapsed)
        WorkoutStatus.PAUSED -> activeAccumulatedMs
        WorkoutStatus.IDLE -> 0L
    }

    private fun snapshotLocked(): TrackingSnapshot {
        val elapsed = elapsedLocked()
        val avg = if (elapsed > 0) distanceM / (elapsed / 1000.0) else 0.0
        return TrackingSnapshot(
            status = status,
            activityType = activityType,
            startWallTimeMs = startWallTimeMs,
            elapsedMs = elapsed,
            distanceM = distanceM,
            currentSpeedMps = currentSpeedMps,
            averageSpeedMps = avg,
            accuracyM = accuracyM,
            gnss = gnss,
            route = route.toList()
        )
    }

    private fun emitLocked() {
        val value = snapshotLocked()
        listeners.forEach { it(value) }
    }
}
