package com.example.gnssfit

import android.Manifest
import android.app.Activity
import android.content.ColorStateList
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var activitySpinner: Spinner
    private lateinit var routeView: RouteView
    private lateinit var statusText: TextView
    private lateinit var timeValue: TextView
    private lateinit var distanceValue: TextView
    private lateinit var speedValue: TextView
    private lateinit var paceValue: TextView
    private lateinit var gnssValue: TextView
    private lateinit var constellationValue: TextView
    private lateinit var startButton: Button
    private lateinit var pauseButton: Button
    private lateinit var finishButton: Button
    private var pendingStart = false

    private val listener: (TrackingSnapshot) -> Unit = { state ->
        runOnUiThread { render(state) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        TrackingRepository.addListener(listener)
    }

    override fun onStop() {
        TrackingRepository.removeListener(listener)
        super.onStop()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.rgb(11, 18, 32))
            isFillViewport = true
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(32))
        }
        scroll.addView(root)

        root.addView(TextView(this).apply {
            text = "GNSS Fit"
            setTextColor(Color.WHITE)
            textSize = 30f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        root.addView(TextView(this).apply {
            text = "GNSS/GPS • спутниковый трекинг высокой точности"
            setTextColor(Color.rgb(170, 183, 200))
            textSize = 14f
            setPadding(0, dp(3), 0, dp(18))
        })

        statusText = TextView(this).apply {
            text = "Готов к тренировке"
            setTextColor(Color.rgb(94, 225, 162))
            textSize = 16f
            setPadding(0, 0, 0, dp(12))
        }
        root.addView(statusText)

        activitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(
                this@MainActivity,
                android.R.layout.simple_spinner_dropdown_item,
                ActivityType.entries.map { it.title }
            )
        }
        root.addView(activitySpinner, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply {
            bottomMargin = dp(14)
        })

        routeView = RouteView(this)
        root.addView(routeView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(260)).apply {
            bottomMargin = dp(18)
        })

        val row1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        timeValue = metricCard(row1, "ВРЕМЯ")
        distanceValue = metricCard(row1, "ДИСТАНЦИЯ")
        root.addView(row1)

        val row2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        speedValue = metricCard(row2, "СКОРОСТЬ")
        paceValue = metricCard(row2, "ТЕМП")
        root.addView(row2)

        gnssValue = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(dp(14), dp(14), dp(14), dp(4))
        }
        constellationValue = TextView(this).apply {
            setTextColor(Color.rgb(170, 183, 200))
            textSize = 13f
            setPadding(dp(14), 0, dp(14), dp(14))
        }
        val gnssCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.rgb(21, 32, 51), 16f)
            addView(gnssValue)
            addView(constellationValue)
        }
        root.addView(gnssCard, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            topMargin = dp(6)
            bottomMargin = dp(18)
        })

        startButton = actionButton("Начать тренировку", Color.rgb(94, 225, 162), Color.rgb(11, 18, 32)) {
            requestStart()
        }
        pauseButton = actionButton("Пауза", Color.rgb(31, 50, 72), Color.WHITE) {
            val state = TrackingRepository.snapshot()
            sendServiceAction(if (state.status == WorkoutStatus.PAUSED) TrackingService.ACTION_RESUME else TrackingService.ACTION_PAUSE)
        }
        finishButton = actionButton("Завершить", Color.rgb(85, 43, 52), Color.WHITE) {
            sendServiceAction(TrackingService.ACTION_STOP)
        }
        val historyButton = actionButton("История тренировок", Color.rgb(31, 50, 72), Color.WHITE) {
            startActivity(Intent(this, HistoryActivity::class.java))
        }
        listOf(startButton, pauseButton, finishButton, historyButton).forEach { button ->
            root.addView(button, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(52)).apply { bottomMargin = dp(10) })
        }

        setContentView(scroll)
        render(TrackingRepository.snapshot())
    }

    private fun requestStart() {
        val manager = getSystemService(LocationManager::class.java)
        if (!manager.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            Toast.makeText(this, "Включите геолокацию/GNSS", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            return
        }
        val missing = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.ACCESS_FINE_LOCATION
            missing += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing += Manifest.permission.POST_NOTIFICATIONS
        }
        if (missing.isNotEmpty()) {
            pendingStart = true
            requestPermissions(missing.distinct().toTypedArray(), REQ_PERMISSIONS)
        } else {
            startTracking()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERMISSIONS && pendingStart) {
            pendingStart = false
            if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                startTracking()
            } else {
                Toast.makeText(this, "Для GNSS-трекинга нужен доступ к точной геопозиции", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun startTracking() {
        val type = ActivityType.entries.getOrElse(activitySpinner.selectedItemPosition) { ActivityType.RUN }
        val intent = Intent(this, TrackingService::class.java)
            .setAction(TrackingService.ACTION_START)
            .putExtra(TrackingService.EXTRA_ACTIVITY_TYPE, type.name)
        startForegroundService(intent)
    }

    private fun sendServiceAction(action: String) {
        startService(Intent(this, TrackingService::class.java).setAction(action))
    }

    private fun render(state: TrackingSnapshot) {
        timeValue.text = Formatters.duration(state.elapsedMs)
        distanceValue.text = Formatters.distance(state.distanceM)
        speedValue.text = Formatters.speedKmh(state.currentSpeedMps.toDouble())
        paceValue.text = Formatters.pace(state.currentSpeedMps.toDouble())
        routeView.points = state.route

        val accuracy = state.accuracyM?.let { "±${it.toInt()} м" } ?: "—"
        gnssValue.text = "GNSS: ${state.gnss.usedInFix}/${state.gnss.visible} спутников • точность $accuracy"
        constellationValue.text = "GPS ${state.gnss.gps}  •  ГЛОНАСС ${state.gnss.glonass}  •  Galileo ${state.gnss.galileo}  •  BeiDou ${state.gnss.beidou}"

        statusText.text = when (state.status) {
            WorkoutStatus.IDLE -> "Готов к тренировке"
            WorkoutStatus.ACTIVE -> "● Запись: ${state.activityType.title}"
            WorkoutStatus.PAUSED -> "Ⅱ Пауза: ${state.activityType.title}"
        }
        val running = state.status != WorkoutStatus.IDLE
        activitySpinner.isEnabled = !running
        startButton.visibility = if (running) View.GONE else View.VISIBLE
        pauseButton.visibility = if (running) View.VISIBLE else View.GONE
        finishButton.visibility = if (running) View.VISIBLE else View.GONE
        pauseButton.text = if (state.status == WorkoutStatus.PAUSED) "Продолжить" else "Пауза"
    }

    private fun metricCard(parent: LinearLayout, label: String): TextView {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(14))
            background = rounded(Color.rgb(21, 32, 51), 16f)
        }
        box.addView(TextView(this).apply {
            text = label
            setTextColor(Color.rgb(170, 183, 200))
            textSize = 11f
        })
        val value = TextView(this).apply {
            text = "—"
            setTextColor(Color.WHITE)
            textSize = 22f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, dp(3), 0, 0)
        }
        box.addView(value)
        parent.addView(box, LinearLayout.LayoutParams(0, dp(88), 1f).apply {
            marginEnd = dp(6)
            bottomMargin = dp(12)
        })
        return value
    }

    private fun actionButton(textValue: String, bg: Int, fg: Int, onClick: () -> Unit): Button = Button(this).apply {
        text = textValue
        setTextColor(fg)
        textSize = 16f
        isAllCaps = false
        backgroundTintList = ColorStateList.valueOf(bg)
        setOnClickListener { onClick() }
    }

    private fun rounded(color: Int, radiusDp: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radiusDp.toInt()).toFloat()
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val REQ_PERMISSIONS = 7
    }
}
