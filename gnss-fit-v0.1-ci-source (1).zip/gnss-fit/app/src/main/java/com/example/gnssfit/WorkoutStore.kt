package com.example.gnssfit

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

object WorkoutStore {
    private const val DIR = "workouts"
    private const val INDEX = "index.json"

    fun save(context: Context, snapshot: TrackingSnapshot): WorkoutSummary {
        val id = UUID.randomUUID().toString()
        val summary = WorkoutSummary(
            id = id,
            activityType = snapshot.activityType,
            startWallTimeMs = snapshot.startWallTimeMs,
            elapsedMs = snapshot.elapsedMs,
            distanceM = snapshot.distanceM,
            averageSpeedMps = snapshot.averageSpeedMps
        )
        val root = JSONObject()
            .put("id", id)
            .put("activityType", summary.activityType.name)
            .put("startWallTimeMs", summary.startWallTimeMs)
            .put("elapsedMs", summary.elapsedMs)
            .put("distanceM", summary.distanceM)
            .put("averageSpeedMps", summary.averageSpeedMps)

        val route = JSONArray()
        snapshot.route.forEach { p ->
            route.put(
                JSONObject()
                    .put("lat", p.lat)
                    .put("lon", p.lon)
                    .put("altitude", p.altitude)
                    .put("timeMs", p.timeMs)
                    .put("accuracyM", p.accuracyM.toDouble())
                    .put("speedMps", p.speedMps.toDouble())
            )
        }
        root.put("route", route)

        val dir = File(context.filesDir, DIR).apply { mkdirs() }
        File(dir, "$id.json").writeText(root.toString())

        val summaries = loadSummaries(context).toMutableList()
        summaries.add(0, summary)
        writeIndex(context, summaries.take(500))
        return summary
    }

    fun loadSummaries(context: Context): List<WorkoutSummary> {
        val file = File(File(context.filesDir, DIR), INDEX)
        if (!file.exists()) return emptyList()
        return runCatching {
            val arr = JSONArray(file.readText())
            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    add(summaryFromJson(o))
                }
            }.sortedByDescending { it.startWallTimeMs }
        }.getOrDefault(emptyList())
    }

    fun loadWorkout(context: Context, id: String): SavedWorkout? {
        val file = File(File(context.filesDir, DIR), "$id.json")
        if (!file.exists()) return null
        return runCatching {
            val root = JSONObject(file.readText())
            val summary = summaryFromJson(root)
            val arr = root.optJSONArray("route") ?: JSONArray()
            val route = buildList {
                for (i in 0 until arr.length()) {
                    val p = arr.getJSONObject(i)
                    add(
                        TrackPoint(
                            lat = p.getDouble("lat"),
                            lon = p.getDouble("lon"),
                            altitude = p.optDouble("altitude", 0.0),
                            timeMs = p.getLong("timeMs"),
                            accuracyM = p.optDouble("accuracyM", 0.0).toFloat(),
                            speedMps = p.optDouble("speedMps", 0.0).toFloat()
                        )
                    )
                }
            }
            SavedWorkout(summary, route)
        }.getOrNull()
    }

    private fun writeIndex(context: Context, summaries: List<WorkoutSummary>) {
        val dir = File(context.filesDir, DIR).apply { mkdirs() }
        val arr = JSONArray()
        summaries.forEach { s ->
            arr.put(
                JSONObject()
                    .put("id", s.id)
                    .put("activityType", s.activityType.name)
                    .put("startWallTimeMs", s.startWallTimeMs)
                    .put("elapsedMs", s.elapsedMs)
                    .put("distanceM", s.distanceM)
                    .put("averageSpeedMps", s.averageSpeedMps)
            )
        }
        File(dir, INDEX).writeText(arr.toString())
    }

    private fun summaryFromJson(o: JSONObject): WorkoutSummary = WorkoutSummary(
        id = o.getString("id"),
        activityType = ActivityType.fromName(o.optString("activityType")),
        startWallTimeMs = o.getLong("startWallTimeMs"),
        elapsedMs = o.getLong("elapsedMs"),
        distanceM = o.getDouble("distanceM"),
        averageSpeedMps = o.optDouble("averageSpeedMps", 0.0)
    )
}
