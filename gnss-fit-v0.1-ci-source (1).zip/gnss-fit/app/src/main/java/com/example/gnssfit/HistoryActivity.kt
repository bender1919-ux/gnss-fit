package com.example.gnssfit

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class HistoryActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(11, 18, 32)) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(18), dp(20), dp(30))
        }
        scroll.addView(root)
        root.addView(TextView(this).apply {
            text = "История"
            setTextColor(Color.WHITE)
            textSize = 28f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(0, 0, 0, dp(16))
        })

        val items = WorkoutStore.loadSummaries(this)
        if (items.isEmpty()) {
            root.addView(TextView(this).apply {
                text = "Пока нет сохранённых тренировок."
                setTextColor(Color.rgb(170, 183, 200))
                textSize = 16f
                gravity = Gravity.CENTER
                setPadding(0, dp(40), 0, 0)
            })
        } else {
            items.forEach { item -> root.addView(workoutCard(item)) }
        }
        setContentView(scroll)
    }

    private fun workoutCard(item: WorkoutSummary): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(16), dp(14), dp(16), dp(14))
        background = GradientDrawable().apply {
            setColor(Color.rgb(21, 32, 51))
            cornerRadius = dp(16).toFloat()
        }
        addView(TextView(this@HistoryActivity).apply {
            text = item.activityType.title
            setTextColor(Color.rgb(94, 225, 162))
            textSize = 17f
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        addView(TextView(this@HistoryActivity).apply {
            text = Formatters.date(item.startWallTimeMs)
            setTextColor(Color.rgb(170, 183, 200))
            textSize = 13f
        })
        addView(TextView(this@HistoryActivity).apply {
            text = "${Formatters.distance(item.distanceM)}   •   ${Formatters.duration(item.elapsedMs)}   •   ${Formatters.speedKmh(item.averageSpeedMps)}"
            setTextColor(Color.WHITE)
            textSize = 15f
            setPadding(0, dp(7), 0, 0)
        })
        setOnClickListener {
            startActivity(Intent(this@HistoryActivity, WorkoutDetailActivity::class.java).putExtra("id", item.id))
        }
        layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
            bottomMargin = dp(10)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
