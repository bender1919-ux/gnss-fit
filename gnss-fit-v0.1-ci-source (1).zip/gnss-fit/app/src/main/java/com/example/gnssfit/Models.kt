package com.example.gnssfit

enum class WorkoutStatus { IDLE, ACTIVE, PAUSED }

enum class ActivityType(val title: String, val maxPlausibleSpeedMps: Float) {
    RUN("Бег", 18f),
    WALK("Ходьба", 9f),
    BIKE("Велосипед", 45f);

    companion object {
        fun fromName(value: String?): ActivityType = entries.firstOrNull { it.name == value } ?: RUN
    }
}

data class TrackPoint(
    val lat: Double,
    val lon: Double,
    val altitude: Double,
    val timeMs: Long,
    val accuracyM: Float,
    val speedMps: Float
)

data class GnssInfo(
    val visible: Int = 0,
    val usedInFix: Int = 0,
    val gps: Int = 0,
    val glonass: Int = 0,
    val galileo: Int = 0,
    val beidou: Int = 0,
    val other: Int = 0
)

data class TrackingSnapshot(
    val status: WorkoutStatus = WorkoutStatus.IDLE,
    val activityType: ActivityType = ActivityType.RUN,
    val startWallTimeMs: Long = 0L,
    val elapsedMs: Long = 0L,
    val distanceM: Double = 0.0,
    val currentSpeedMps: Float = 0f,
    val averageSpeedMps: Double = 0.0,
    val accuracyM: Float? = null,
    val gnss: GnssInfo = GnssInfo(),
    val route: List<TrackPoint> = emptyList()
)

data class WorkoutSummary(
    val id: String,
    val activityType: ActivityType,
    val startWallTimeMs: Long,
    val elapsedMs: Long,
    val distanceM: Double,
    val averageSpeedMps: Double
)

data class SavedWorkout(
    val summary: WorkoutSummary,
    val route: List<TrackPoint>
)
