# GNSS Fit MVP does not require custom ProGuard rules yet.
